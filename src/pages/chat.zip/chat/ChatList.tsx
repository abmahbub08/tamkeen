import React from "react";
import { Chat } from "./type";

interface ChatListProps {
  currentUser: string;
  onSelectChat: (chat: Chat) => void;
  onStartChat: () => void;
}

const ChatList: React.FC<ChatListProps> = ({ currentUser, onSelectChat, onStartChat }) => {
  const chats: Chat[] = []; // Replace with actual chat fetching logic

  return (
    <div className="p-4">
      <h2 className="text-xl font-bold mb-4">Chats</h2>
      {chats.length > 0 ? (
        <ul>
          {chats.map((chat) => (
            <li
              key={chat.id}
              className="p-2 bg-gray-100 rounded mb-2 hover:bg-gray-200 cursor-pointer"
              onClick={() => onSelectChat(chat)}
            >
              {chat.name}
            </li>
          ))}
        </ul>
      ) : (
        <div className="text-center">
          <p className="text-gray-500 mb-4">No chats available</p>
          <button
            onClick={onStartChat}
            className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
          >
            Start New Chat
          </button>
        </div>
      )}
    </div>
  );
};

export default ChatList;
