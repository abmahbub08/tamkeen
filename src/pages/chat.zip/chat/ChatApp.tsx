import React, { useState } from "react";
import ChatList from "./ChatList";
import ChatWindow from "./ChatWindow";
import StartChatModal from "./StartChat";
import { Chat } from "./type";

interface ChatAppProps {
  currentUser: string;
}

const ChatApp: React.FC<ChatAppProps> = ({ currentUser }) => {
  const [selectedChat, setSelectedChat] = useState<Chat | null>(null);
  const [showModal, setShowModal] = useState<boolean>(false);

  const handleStartChat = () => {
    setShowModal(true);
  };

  return (
    <div className="flex h-screen">
      {/* Chat List */}
      <div className="w-1/3 bg-gray-200">
        <ChatList
          currentUser={currentUser}
          onSelectChat={setSelectedChat}
          onStartChat={handleStartChat}
        />
      </div>

      {/* Chat Window */}
      <div className="w-2/3 bg-white">
        {selectedChat ? (
          <ChatWindow currentUser={currentUser} chat={selectedChat} />
        ) : (
          <div className="flex flex-col justify-center items-center h-full">
            <p className="text-gray-500 mb-4">
              Select a chat to start messaging
            </p>
            <button
              onClick={handleStartChat}
              className="bg-blue-600 text-white px-4 py-2 rounded hover:bg-blue-700"
            >
              Start New Chat
            </button>
          </div>
        )}
      </div>

      {/* Modal for starting a new chat */}
      {showModal && (
        <StartChatModal
          currentUser={currentUser}
          onClose={() => setShowModal(false)}
          onSelectChat={setSelectedChat}
        />
      )}
    </div>
  );
};

export default ChatApp;
