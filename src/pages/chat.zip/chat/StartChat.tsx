import React, { useEffect, useState } from "react";
import { Chat } from "./type";

interface StartChatModalProps {
  currentUser: string;
  onClose: () => void;
  onSelectChat: (chat: Chat) => void;
}

interface Referrer {
  id: number;
  name: string;
  email: string;
  phone: string;
}

const StartChatModal: React.FC<StartChatModalProps> = ({
  currentUser,
  onClose,
  onSelectChat,
}) => {
  const [referrers, setReferrers] = useState<Referrer[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchReferrers = async () => {
      try {
        const response = await fetch(
          `http://127.0.0.1:8000/api/pyramid/referral-tree/${currentUser}`
        );
        const data = await response.json();

        if (response.ok) {
          const allReferrals = data.referral_tree.flatMap(
            (level: any) => level.referrals
          );
          setReferrers(
            allReferrals.map((ref: any) => ({
              id: ref.user.id,
              name: ref.user.name,
              email: ref.user.email,
              phone: ref.user.phone,
            }))
          );
        } else {
          setError(data.message || "Failed to fetch referrers.");
        }
      } catch (err) {
        setError("An error occurred while fetching referrers.");
        console.error(err);
      } finally {
        setLoading(false);
      }
    };

    fetchReferrers();
  }, [currentUser]);

  const handleSelectReferrer = (referrer: Referrer) => {
    const newChat: Chat = {
      id: referrer.id,
      name: referrer.name,
      messages: [],
    };
    onSelectChat(newChat);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex justify-center items-center">
      <div className="bg-white rounded-lg p-6 w-96">
        <h2 className="text-xl font-bold mb-4">Start a New Chat</h2>
        {loading ? (
          <div className="text-center">Loading referrers...</div>
        ) : error ? (
          <div className="text-red-500">{error}</div>
        ) : (
          <ul className="space-y-2">
            {referrers.map((referrer) => (
              <li
                key={referrer.id}
                className="p-2 bg-gray-100 rounded hover:bg-gray-200 cursor-pointer"
                onClick={() => handleSelectReferrer(referrer)}
              >
                <p className="font-bold">{referrer.name}</p>
                <p className="text-sm text-gray-500">{referrer.email}</p>
                <p className="text-sm text-gray-500">{referrer.phone}</p>
              </li>
            ))}
          </ul>
        )}
        <button
          onClick={onClose}
          className="mt-4 w-full bg-red-600 text-white py-2 rounded hover:bg-red-700"
        >
          Cancel
        </button>
      </div>
    </div>
  );
};

export default StartChatModal;
