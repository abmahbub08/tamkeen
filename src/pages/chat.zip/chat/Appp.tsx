import ChatApp from "./ChatApp";

const App = () => {
  const currentUser = "6"; // Replace with your logic to fetch the user ID

  return <ChatApp currentUser={currentUser} />;
};

export default App;