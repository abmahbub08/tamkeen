import React, { useEffect, useState } from "react";
import {
  collection,
  addDoc,
  query,
  orderBy,
  onSnapshot,
  serverTimestamp,
} from "firebase/firestore";
import { db } from "./firebase";
import { Chat, Message } from "./type";
import { format } from "date-fns";

interface ChatWindowProps {
  currentUser: string;
  chat: Chat;
}

const ChatWindow: React.FC<ChatWindowProps> = ({ currentUser, chat }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState<string>("");
  const [loading, setLoading] = useState<boolean>(false);

  useEffect(() => {
    const q = query(
      collection(db, `chats/${chat.id}/messages`),
      orderBy("timestamp", "asc")
    );
  
    const unsubscribe = onSnapshot(q, (snapshot) => {
      setMessages(
        snapshot.docs.map((doc) => {
          const data = doc.data();
          return {
            id: doc.id,
            senderId: data.senderId,
            content: data.content,
            timestamp: data.timestamp?.toDate() || new Date(), // Ensure timestamp is converted to a Date
          } as Message; // Assert type explicitly
        })
      );
    });
  
    return () => unsubscribe();
  }, [chat.id]);
  

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    setLoading(true);
    try {
      await addDoc(collection(db, `chats/${chat.id}/messages`), {
        senderId: currentUser,
        content: newMessage,
        timestamp: serverTimestamp(),
      });
      setNewMessage("");
    } catch (error) {
      console.error("Failed to send message:", error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="h-full flex flex-col">
      {/* Messages */}
      <div className="flex-grow overflow-y-auto p-4 space-y-4">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`p-2 rounded-md max-w-xs ${
              msg.senderId === currentUser
                ? "bg-blue-500 text-white ml-auto"
                : "bg-gray-200 text-black"
            }`}
          >
            <p className="text-sm font-semibold">
              {msg.senderId === currentUser ? "You" : chat.name}
            </p>
            <p>{msg.content}</p>
            <span className="text-xs text-gray-500">
              {format(new Date(msg.timestamp), "p, MMM d")}
            </span>
          </div>
        ))}
      </div>

      {/* Input */}
      <div className="p-4 border-t">
        <div className="flex">
          <input
            type="text"
            placeholder="Type a message"
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            className="flex-grow border rounded-l-md p-2"
            disabled={loading}
            aria-label="Message input"
          />
          <button
            onClick={sendMessage}
            className={`px-4 rounded-r-md ${
              loading ? "bg-gray-400" : "bg-blue-500 text-white"
            }`}
            disabled={loading}
            aria-label="Send message"
          >
            {loading ? "Sending..." : "Send"}
          </button>
        </div>
      </div>
    </div>
  );
};

export default ChatWindow;
