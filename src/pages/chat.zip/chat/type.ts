export interface Chat {
    id: string; // Firestore document ID
    participants: string[]; // List of user IDs in the chat
    lastMessage?: string; // The last message sent in the chat
    unreadMessages?: { [userId: string]: number }; // Unread message count for each participant
    lastUpdated?: Date; // Timestamp of the last update
  }
  
  
  export interface Message {
    id: string; // Changed to string to match Firebase
    senderId: string;
    content: string;
    timestamp: Date;
  }
  
  
  export interface Referrer {
    id: number; // Referrer's user ID
    name: string; // Referrer's name
    email: string; // Referrer's email
    phone: string; // Referrer's phone number
  }
  